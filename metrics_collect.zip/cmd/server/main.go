package main

import "github.com/dmitryDevGoMid/go-service-collect-metrics/internal/app/server"

func main() {
	server.Run()
}
