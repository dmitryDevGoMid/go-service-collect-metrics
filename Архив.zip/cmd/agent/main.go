package main

import (
	"github.com/dmitryDevGoMid/go-service-collect-metrics/internal/app/agent"
)

func main() {
	agent.Run()
}
